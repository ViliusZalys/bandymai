package lt.vtvpmc.ems.akademijait.Vilius;

import java.math.BigInteger;

public class BigNumbers {
    public static BigInteger addTwoIntegerNumbers (BigInteger numberOne, BigInteger numberTwo) {
        System.out.println(numberOne);
        return numberOne.add(numberTwo);
    }
}
